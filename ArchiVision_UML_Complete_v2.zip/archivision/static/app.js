document.addEventListener("DOMContentLoaded",()=>{
 const input=document.getElementById("project_zip");
 if(input) input.addEventListener("change",()=>{const label=document.getElementById("file-label");if(label&&input.files[0])label.textContent=input.files[0].name;});
 const search=document.getElementById("file-search");
 if(search) search.addEventListener("input",()=>{const q=search.value.toLowerCase();document.querySelectorAll(".file-item").forEach(el=>el.style.display=el.dataset.search.includes(q)?"flex":"none");});
 if(window.ARCHIVISION_DATA){
   const data=window.ARCHIVISION_DATA, container=document.getElementById("cy");
   if(container&&window.cytoscape){
     const colors={"Python":"#7185ff","Java":"#b08cff","JavaScript":"#4dd4a2","TypeScript":"#55b7df"};
     const elements=[
       ...data.nodes.map(n=>({data:{id:n.id,label:n.label,language:n.language,lines:n.lines},classes:n.language})),
       ...data.edges.map((e,i)=>({data:{id:"e"+i,source:e.source,target:e.target}}))
     ];
     const cy=cytoscape({container,elements,style:[
       {selector:"node",style:{"background-color":ele=>colors[ele.data("language")]||"#ffb86b","label":"data(label)","color":"#e9edff","font-size":10,"text-valign":"bottom","text-margin-y":8,"width":24,"height":24,"border-width":1,"border-color":"#aab7ff"}},
       {selector:"edge",style:{"width":1.5,"line-color":"#65749c","target-arrow-color":"#65749c","target-arrow-shape":"triangle","curve-style":"bezier","arrow-scale":.7}},
       {selector:":selected",style:{"border-width":4,"border-color":"#fff","background-color":"#fff"}}
     ],layout:{name:"cose",animate:false,padding:35},userZoomingEnabled:true,userPanningEnabled:true});
     cy.on("tap","node",e=>{const n=e.target;const info=document.getElementById("node-info");if(info)info.textContent=n.data("id")+" · "+n.data("language");});
   } else if(container) container.innerHTML="<div style='padding:30px;color:#9aa7c4'>Graph library unavailable. Check your internet connection.</div>";
 }
 const modal=document.getElementById("explain-modal");
 const close=document.getElementById("close-modal");
 if(close)close.onclick=()=>modal.classList.add("hidden");
 if(modal)modal.addEventListener("click",e=>{if(e.target===modal)modal.classList.add("hidden")});
 document.querySelectorAll(".explain-btn").forEach(btn=>btn.addEventListener("click",async()=>{
   modal.classList.remove("hidden");
   document.getElementById("explain-title").textContent=btn.dataset.path;
   const body=document.getElementById("explain-body");body.textContent="Analysing source file…";
   try{
     const res=await fetch("/api/explain",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({project_id:window.ARCHIVISION_PROJECT,file_path:btn.dataset.path})});
     const data=await res.json();body.textContent=data.explanation||data.error||"No explanation returned.";
   }catch(e){body.textContent="Could not reach the analysis service. Please try again."}
 }));

 // UML Studio: render six Mermaid diagrams, explain the active view and export SVG/PNG.
 const umlRoot=document.getElementById("uml-diagram");
 if(umlRoot&&window.ARCHIVISION_UML&&window.mermaid){
   const diagrams=window.ARCHIVISION_UML;
   mermaid.initialize({startOnLoad:false,theme:"dark",securityLevel:"strict",flowchart:{curve:"basis"}});
   let active="component";
   const renderUml=async()=>{
     const source=diagrams[active]||"flowchart TB\n  Empty[No diagram data]";
     umlRoot.innerHTML="";
     try{const result=await mermaid.render("archivision-uml-"+active,source);umlRoot.innerHTML=result.svg;}
     catch(err){umlRoot.textContent="Could not render this diagram. This can happen when the source structure is too complex or the browser cannot load Mermaid.";}
   };
   document.querySelectorAll(".uml-tab").forEach(btn=>btn.addEventListener("click",()=>{
     document.querySelectorAll(".uml-tab").forEach(b=>b.classList.remove("active"));btn.classList.add("active");active=btn.dataset.diagram;renderUml();
   }));
   const saveBlob=(blob,name)=>{const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
   const download=document.getElementById("uml-download");
   if(download)download.addEventListener("click",()=>{
     const svg=umlRoot.querySelector("svg");if(!svg)return;
     const clone=svg.cloneNode(true);if(!clone.getAttribute("xmlns"))clone.setAttribute("xmlns","http://www.w3.org/2000/svg");
     saveBlob(new Blob([new XMLSerializer().serializeToString(clone)],{type:"image/svg+xml;charset=utf-8"}),"archivision-"+active+"-diagram.svg");
   });
   const png=document.getElementById("uml-download-png");
   if(png)png.addEventListener("click",()=>{
     const svg=umlRoot.querySelector("svg");if(!svg)return;
     const clone=svg.cloneNode(true);if(!clone.getAttribute("xmlns"))clone.setAttribute("xmlns","http://www.w3.org/2000/svg");
     const markup=new XMLSerializer().serializeToString(clone);const blob=new Blob([markup],{type:"image/svg+xml;charset=utf-8"});const url=URL.createObjectURL(blob);const img=new Image();
     img.onload=()=>{const canvas=document.createElement("canvas");canvas.width=Math.max(900,img.width||900);canvas.height=Math.max(600,img.height||600);const ctx=canvas.getContext("2d");ctx.fillStyle="#111827";ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(img,0,0,canvas.width,canvas.height);canvas.toBlob(out=>{if(out)saveBlob(out,"archivision-"+active+"-diagram.png");URL.revokeObjectURL(url);},"image/png");};
     img.onerror=()=>{URL.revokeObjectURL(url);alert("PNG export failed. Please use SVG export instead.");};img.src=url;
   });
   const explain=document.getElementById("uml-explain");
   if(explain)explain.addEventListener("click",async()=>{
     explain.disabled=true;const original=explain.textContent;explain.textContent="Explaining…";
     try{const res=await fetch("/api/explain-diagram",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({project_id:window.ARCHIVISION_PROJECT,diagram_type:active})});const data=await res.json();
       const modal=document.getElementById("explain-modal");const title=document.getElementById("explain-title");const body=document.getElementById("explain-body");
       title.textContent=active.charAt(0).toUpperCase()+active.slice(1)+" diagram explanation";body.textContent=data.explanation||data.error||"No explanation returned.";modal.classList.remove("hidden");
     }catch(err){alert("Could not reach the diagram explanation service.");}
     finally{explain.disabled=false;explain.textContent=original;}
   });
   renderUml();
 }

});
