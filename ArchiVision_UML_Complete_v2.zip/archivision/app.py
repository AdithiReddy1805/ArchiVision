import os, re, json, uuid, zipfile, sqlite3, shutil
from pathlib import Path
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_file
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from dotenv import load_dotenv
import networkx as nx

load_dotenv()
ROOT = Path(__file__).parent.resolve()
UPLOADS = ROOT / "uploads"
REPORTS = ROOT / "reports"
UPLOADS.mkdir(exist_ok=True); REPORTS.mkdir(exist_ok=True)

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET", "change-this-secret-before-deployment")
app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024

DB = ROOT / "archivision.db"
ALLOWED_EXTS = {
    ".py":"Python", ".java":"Java", ".js":"JavaScript", ".jsx":"JavaScript",
    ".ts":"TypeScript", ".tsx":"TypeScript", ".c":"C", ".h":"C/C++",
    ".cc":"C++", ".cpp":"C++", ".hpp":"C++", ".cs":"C#", ".php":"PHP",
    ".go":"Go", ".rb":"Ruby", ".kt":"Kotlin", ".kts":"Kotlin",
    ".swift":"Swift", ".rs":"Rust", ".scala":"Scala", ".html":"HTML",
    ".css":"CSS", ".scss":"SCSS", ".sql":"SQL", ".sh":"Shell",
    ".vue":"Vue", ".dart":"Dart", ".lua":"Lua", ".r":"R",
    ".m":"Objective-C", ".mm":"Objective-C++", ".pl":"Perl",
    ".ex":"Elixir", ".exs":"Elixir", ".erl":"Erlang", ".hs":"Haskell",
    ".ml":"OCaml", ".clj":"Clojure", ".groovy":"Groovy", ".yaml":"YAML",
    ".yml":"YAML", ".xml":"XML", ".json":"JSON", ".toml":"TOML"
}
LANG_PARSER = {
    "Python":"python", "Java":"java", "JavaScript":"javascript",
    "TypeScript":"typescript", "C":"c", "C/C++":"cpp", "C++":"cpp",
    "C#":"c_sharp", "PHP":"php", "Go":"go", "Ruby":"ruby",
    "Kotlin":"kotlin", "Swift":"swift", "Rust":"rust", "Scala":"scala",
    "HTML":"html", "CSS":"css", "SCSS":"scss", "SQL":"sql",
    "Shell":"bash", "Vue":"vue", "Dart":"dart", "Lua":"lua",
    "R":"r", "Objective-C":"objc", "Objective-C++":"objc",
    "Perl":"perl", "Elixir":"elixir", "Erlang":"erlang",
    "Haskell":"haskell", "OCaml":"ocaml", "Clojure":"clojure",
    "Groovy":"groovy", "YAML":"yaml", "XML":"xml", "JSON":"json",
    "TOML":"toml"
}
MAX_FILES = 1200
MAX_FILE_BYTES = 500_000

def db():
    con = sqlite3.connect(DB); con.row_factory = sqlite3.Row
    return con

def init_db():
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY, username TEXT UNIQUE, password TEXT)""")
        con.execute("""CREATE TABLE IF NOT EXISTS projects(
            id TEXT PRIMARY KEY, user_id INTEGER, name TEXT, created_at TEXT,
            analysis_json TEXT)""")
init_db()

def tree_sitter_extract(source, language):
    """Best-effort structural parsing through Tree-sitter language packs."""
    try:
        from tree_sitter_language_pack import get_parser
        parser = get_parser(LANG_PARSER.get(language, ""))
        tree = parser.parse(source.encode("utf-8", errors="replace"))
        root = tree.root_node
        defs, imports = [], []
        stack = [root]
        while stack:
            node = stack.pop()
            typ = node.type.lower()
            snippet = source.encode("utf-8", errors="replace")[node.start_byte:node.end_byte].decode("utf-8", errors="replace")
            if any(k in typ for k in ["class_definition", "class_declaration", "interface_declaration", "struct_item", "trait_item"]):
                defs.append({"kind":"class/type", "name": extract_name(snippet), "line": node.start_point[0]+1})
            elif any(k in typ for k in ["function_definition", "function_declaration", "method_definition", "method_declaration", "function_item"]):
                defs.append({"kind":"function/method", "name": extract_name(snippet), "line": node.start_point[0]+1})
            if any(k in typ for k in ["import", "include", "using_directive", "package_clause", "mod_declaration"]):
                compact = " ".join(snippet.strip().split())[:180]
                if compact and compact not in imports: imports.append(compact)
            stack.extend(reversed(node.children))
        return defs[:250], imports[:250], True
    except Exception:
        return [], [], False

def extract_name(snippet):
    patterns = [
        r'\b(?:class|interface|struct|trait|enum)\s+([A-Za-z_$][\w$]*)',
        r'\b(?:def|function|func|fn)\s+([A-Za-z_$][\w$]*)',
        r'\b([A-Za-z_$][\w$]*)\s*\('
    ]
    for p in patterns:
        m = re.search(p, snippet)
        if m: return m.group(1)
    return "unnamed"

def fallback_extract(source):
    defs = []
    for i, line in enumerate(source.splitlines(), 1):
        m = re.search(r'^\s*(?:async\s+)?(?:def|class|function|func|fn)\s+([A-Za-z_$][\w$]*)', line)
        if m: defs.append({"kind":"definition", "name":m.group(1), "line":i})
    imports = []
    for line in source.splitlines():
        s = line.strip()
        if re.match(r'(import |from |#include|using |require\(|include\s)', s):
            imports.append(s[:180])
    return defs[:250], list(dict.fromkeys(imports))[:250]

def analyse_project(project_dir):
    records, lang_counts, total_lines = [], {}, 0
    all_paths = [p for p in project_dir.rglob("*") if p.is_file() and p.suffix.lower() in ALLOWED_EXTS]
    all_paths = all_paths[:MAX_FILES]
    for path in all_paths:
        try:
            if path.stat().st_size > MAX_FILE_BYTES: continue
            source = path.read_text(encoding="utf-8", errors="replace")
        except Exception: continue
        lang = ALLOWED_EXTS[path.suffix.lower()]
        lang_counts[lang] = lang_counts.get(lang, 0) + 1
        total_lines += len(source.splitlines())
        defs, imports, parsed = tree_sitter_extract(source, lang)
        if not parsed: defs, imports = fallback_extract(source)
        records.append({
            "path":str(path.relative_to(project_dir)).replace("\\","/"),
            "language":lang, "lines":len(source.splitlines()),
            "definitions":defs, "imports":imports, "parser_used":parsed
        })

    # Resolve simple import references to files in the uploaded project.
    graph = nx.DiGraph()
    by_stem = {}
    for r in records:
        graph.add_node(r["path"], language=r["language"], lines=r["lines"])
        by_stem.setdefault(Path(r["path"]).stem.lower(), []).append(r["path"])
    for r in records:
        for imp in r["imports"]:
            tokens = re.findall(r'[A-Za-z_][\w.]*', imp)
            candidates = set()
            for token in tokens:
                last = token.split(".")[-1].lower()
                if last in by_stem: candidates.update(by_stem[last])
            for target in candidates:
                if target != r["path"]: graph.add_edge(r["path"], target, relation="imports")
    cycles = []
    try:
        cycles = [list(c) for c in nx.simple_cycles(graph) if len(c) > 1][:30]
    except Exception: pass
    degree = dict(graph.degree())
    isolated = [n for n,d in degree.items() if d == 0]
    total_defs = sum(len(r["definitions"]) for r in records)
    total_imports = sum(len(r["imports"]) for r in records)
    # Transparent heuristic score, not a formal quality certification.
    score = max(0, min(100, 100 - len(cycles)*8 - len(isolated)*1.5))
    nodes = [{"id":n, "label":Path(n).name, "language":graph.nodes[n]["language"],
              "lines":graph.nodes[n]["lines"], "degree":degree.get(n,0)} for n in graph.nodes]
    edges = [{"source":u, "target":v} for u,v in graph.edges]
    # Build evidence-based UML views from the extracted source structure.
    # Mermaid is used for rendering; diagrams are generated from static analysis, not AI guesses.
    def mid(value):
        return re.sub(r"[^A-Za-z0-9_]", "_", value)

    class_lines = ["classDiagram"]
    class_count = 0
    for record in records:
        for definition in record["definitions"]:
            if definition["kind"] == "class/type":
                class_name = mid(definition["name"])
                class_lines.append(f"class {class_name}")
                class_count += 1
    if class_count == 0:
        class_lines += ["note for NoClasses \"No class/type declarations were detected by the available parser.\""]

    component_lines = ["flowchart LR"]
    for index, node in enumerate(nodes):
        component_lines.append(f'  F{index}["{node["label"].replace(chr(34), chr(39))}<br/>{node["language"]}"]')
    node_index = {node["id"]: i for i, node in enumerate(nodes)}
    for edge in edges:
        component_lines.append(f'  F{node_index[edge["source"]]} -->|imports| F{node_index[edge["target"]]}')
    if not nodes:
        component_lines.append('  Empty["No supported source files found"]')

    package_lines = ["flowchart TB"]
    folders = {}
    for index, node in enumerate(nodes):
        folder = str(Path(node["id"]).parent).replace("\\", "/")
        if folder == ".": folder = "root"
        folders.setdefault(folder, []).append((index, node["label"]))
    for folder_index, (folder, entries) in enumerate(folders.items()):
        package_lines.append(f'  subgraph P{folder_index}["{folder.replace(chr(34), chr(39))}"]')
        for index, label in entries:
            package_lines.append(f'    F{index}["{label.replace(chr(34), chr(39))}"]')
        package_lines.append("  end")
    if not folders: package_lines.append('  Empty["No packages detected"]')

    # Sequence diagram: inferred module-to-module messages from import edges.
    sequence_lines = ["sequenceDiagram"]
    sequence_nodes = []
    for edge in edges:
        for path in (edge["source"], edge["target"]):
            if path not in sequence_nodes: sequence_nodes.append(path)
    sequence_nodes = sequence_nodes[:12]
    sequence_ids = {path: f"M{i}" for i, path in enumerate(sequence_nodes)}
    for path, ident in sequence_ids.items():
        label = Path(path).name.replace('"', "'")[:45]
        sequence_lines.append(f'  participant {ident} as {label}')
    seq_count = 0
    for edge in edges:
        if edge["source"] in sequence_ids and edge["target"] in sequence_ids and seq_count < 30:
            sequence_lines.append(f'  {sequence_ids[edge["source"]]}->>{sequence_ids[edge["target"]]}: imports / uses')
            seq_count += 1
    if not seq_count:
        if sequence_nodes:
            sequence_lines.append('  Note over M0: No cross-file interactions were inferred')
        else:
            sequence_lines.append('  participant System')
            sequence_lines.append('  Note over System: No module relationships detected')

    # Activity diagram: a cautious workflow sketch from detected entry points and functions.
    activity_lines = ["flowchart TD", '  Start((Start))']
    function_defs = []
    for record in records:
        for definition in record["definitions"]:
            if definition.get("kind") in ("function/method", "definition"):
                function_defs.append((definition.get("name", "function"), record["path"]))
    function_defs = function_defs[:10]
    activity_lines.append('  Scan["Scan project files"]')
    activity_lines.append('  Start --> Scan')
    previous = "Scan"
    for i, (name, path) in enumerate(function_defs):
        ident = f"Step{i}"
        label = (name + " · " + Path(path).name).replace('"', "'")[:65]
        activity_lines.append(f'  {ident}["{label}"]')
        activity_lines.append(f'  {previous} --> {ident}')
        previous = ident
    activity_lines.append('  Report["Generate analysis and diagrams"]')
    activity_lines.append(f'  {previous} --> Report')
    activity_lines.append('  End((End))')
    activity_lines.append('  Report --> End')

    # Use-case view: actors and capabilities inferred from common routes and names.
    usecase_lines = ["flowchart LR", '  User([User])', '  subgraph App["Analysed application"]']
    capabilities = []
    for record in records:
        try:
            src = (project_dir / record["path"]).read_text(encoding="utf-8", errors="replace")[:MAX_FILE_BYTES]
        except Exception:
            src = ""
        for route in re.findall(r'@app\.route\([\'\"]([^\'\"]+)', src):
            method = route.strip() or "/"
            if method not in capabilities: capabilities.append(method)
    if not capabilities:
        for name, _path in function_defs:
            if name not in capabilities: capabilities.append(name)
    capabilities = capabilities[:10]
    if not capabilities: capabilities = ["Use application"]
    for i, capability in enumerate(capabilities):
        label = capability.replace('"', "'")[:55]
        usecase_lines.append(f'    UC{i}(["{label}"])')
        usecase_lines.append(f'  User --> UC{i}')
    usecase_lines.append('  end')

    return {
        "summary":{"files":len(records),"lines":total_lines,"definitions":total_defs,"imports":total_imports,
                   "languages":lang_counts,"cycles":len(cycles),"isolated":len(isolated),"health":round(score)},
        "files":records,"cycles":cycles,"isolated":isolated,
        "graph":{"nodes":nodes,"edges":edges},
        "uml":{"class": "\n".join(class_lines), "component": "\n".join(component_lines),
               "package": "\n".join(package_lines), "sequence": "\n".join(sequence_lines),
               "activity": "\n".join(activity_lines), "usecase": "\n".join(usecase_lines),
               "class_count": class_count},
        "notes":["Static analysis is best-effort and does not execute uploaded code.",
                 "Dependency links are inferred from import/include references and may miss dynamic relationships.",
                 "Class diagrams currently show detected class/type declarations; inheritance and member signatures require deeper language-specific parsing.",
                 "Component and package views are inferred from file dependencies and folder structure.",
                 "Architecture health is a transparent heuristic, not a security or quality certification."]
    }

def safe_extract(zip_path, destination):
    with zipfile.ZipFile(zip_path) as z:
        for info in z.infolist():
            target = (destination / info.filename).resolve()
            if not str(target).startswith(str(destination.resolve()) + os.sep) and target != destination.resolve():
                raise ValueError("Unsafe archive path detected.")
        z.extractall(destination)

def login_required(fn):
    from functools import wraps
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("user_id"): return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

@app.route("/")
def index():
    return redirect(url_for("dashboard") if session.get("user_id") else url_for("login"))

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username","").strip()
        password = request.form.get("password","")
        if len(username)<3 or len(password)<8:
            flash("Use a username of 3+ characters and password of at least 8 characters.")
        else:
            try:
                with db() as con:
                    con.execute("INSERT INTO users(username,password) VALUES(?,?)",
                                (username, generate_password_hash(password)))
                flash("Account created. Please sign in."); return redirect(url_for("login"))
            except sqlite3.IntegrityError: flash("That username already exists.")
    return render_template("auth.html", mode="register")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        with db() as con:
            user = con.execute("SELECT * FROM users WHERE username=?",
                               (request.form.get("username","").strip(),)).fetchone()
        if user and check_password_hash(user["password"], request.form.get("password","")):
            session["user_id"] = user["id"]; session["username"] = user["username"]
            return redirect(url_for("dashboard"))
        flash("Incorrect username or password.")
    return render_template("auth.html", mode="login")

@app.route("/logout")
def logout():
    session.clear(); return redirect(url_for("login"))

@app.route("/dashboard")
@login_required
def dashboard():
    with db() as con:
        projects = con.execute("SELECT * FROM projects WHERE user_id=? ORDER BY created_at DESC",
                               (session["user_id"],)).fetchall()
    return render_template("dashboard.html", projects=projects)

@app.route("/analyse", methods=["POST"])
@login_required
def analyse():
    file = request.files.get("project_zip")
    if not file or not file.filename.lower().endswith(".zip"):
        flash("Please upload a ZIP archive."); return redirect(url_for("dashboard"))
    pid = uuid.uuid4().hex[:12]
    work = UPLOADS / pid; work.mkdir()
    zip_path = work / secure_filename(file.filename)
    file.save(zip_path)
    try:
        safe_extract(zip_path, work / "source")
        result = analyse_project(work / "source")
        name = Path(file.filename).stem
        with db() as con:
            con.execute("INSERT INTO projects(id,user_id,name,created_at,analysis_json) VALUES(?,?,?,?,?)",
                        (pid,session["user_id"],name,datetime.now().isoformat(timespec="minutes"),json.dumps(result)))
        return redirect(url_for("project", project_id=pid))
    except Exception as e:
        shutil.rmtree(work, ignore_errors=True)
        flash("Could not analyse archive: " + str(e)); return redirect(url_for("dashboard"))

def get_project(project_id):
    with db() as con:
        return con.execute("SELECT * FROM projects WHERE id=? AND user_id=?",
                           (project_id,session["user_id"])).fetchone()

@app.route("/project/<project_id>")
@login_required
def project(project_id):
    p = get_project(project_id)
    if not p: return redirect(url_for("dashboard"))
    data = json.loads(p["analysis_json"])
    return render_template("project.html", project=p, data=data)

@app.route("/api/explain", methods=["POST"])
@login_required
def explain():
    body = request.get_json(force=True)
    project_id, file_path = body.get("project_id"), body.get("file_path")
    p = get_project(project_id)
    if not p: return jsonify(error="Project not found"),404
    data = json.loads(p["analysis_json"])
    item = next((f for f in data["files"] if f["path"] == file_path),None)
    if not item: return jsonify(error="File not found"),404
    source_path = UPLOADS / project_id / "source" / file_path
    source = source_path.read_text(encoding="utf-8",errors="replace")[:12000]
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return jsonify(explanation=f"AI API is not configured. Static analysis found a {item['language']} file with {item['lines']} lines, {len(item['definitions'])} detected definitions and {len(item['imports'])} import statements. Add OPENAI_API_KEY to .env to enable AI explanations.", mode="static")
    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key, base_url=os.getenv("OPENAI_BASE_URL") or None)
        model = os.getenv("OPENAI_MODEL","gpt-4o-mini")
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role":"system","content":"You are a careful software architecture analyst. Explain code accurately. Mention uncertainty; never claim code was executed."},
                {"role":"user","content":f"Explain this {item['language']} source file for a developer. Cover purpose, main components, dependencies, flow, and possible design concerns. Keep it structured.\n\nFile: {file_path}\n\n{source}"}
            ], temperature=0.2
        )
        return jsonify(explanation=response.choices[0].message.content, mode="ai")
    except Exception as e:
        return jsonify(explanation="AI request failed: "+str(e), mode="error"), 502

@app.route("/api/explain-diagram", methods=["POST"])
@login_required
def explain_diagram():
    body = request.get_json(force=True)
    project_id, diagram_type = body.get("project_id"), body.get("diagram_type")
    p = get_project(project_id)
    if not p: return jsonify(error="Project not found"), 404
    data = json.loads(p["analysis_json"])
    source = data.get("uml", {}).get(diagram_type)
    allowed = {"class", "component", "package", "sequence", "activity", "usecase"}
    if diagram_type not in allowed or not source:
        return jsonify(error="Diagram type not found"), 404
    fallback = (f"{diagram_type.title()} diagram for {p['name']}. It was generated from static source-code analysis. "
                "Relationships are inferred and may be incomplete. Review the source files before treating this as a definitive design.")
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return jsonify(explanation=fallback, mode="static")
    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key, base_url=os.getenv("OPENAI_BASE_URL") or None)
        response = client.chat.completions.create(
            model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"), temperature=0.2,
            messages=[
                {"role":"system", "content":"You explain software diagrams accurately. Only describe elements present in the supplied Mermaid diagram. State when relationships are inferred; do not invent missing behavior."},
                {"role":"user", "content":f"Explain this {diagram_type} diagram for project {p['name']}. Explain nodes, relationships, flow and limitations in beginner-friendly language.\n\n{source}"}
            ])
        return jsonify(explanation=response.choices[0].message.content, mode="ai")
    except Exception as e:
        return jsonify(explanation=fallback + "\n\nAI explanation unavailable: " + str(e), mode="static")

@app.route("/report/<project_id>")
@login_required
def report(project_id):
    p = get_project(project_id)
    if not p: return redirect(url_for("dashboard"))
    data = json.loads(p["analysis_json"])
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
        from reportlab.lib import colors
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.lib.units import mm
        out = REPORTS / f"ArchiVision-{project_id}.pdf"
        styles = getSampleStyleSheet()
        doc = SimpleDocTemplate(str(out), pagesize=A4)
        story = [Paragraph("ArchiVision Architecture Report",styles["Title"]),
                 Paragraph(p["name"],styles["Heading2"]),Spacer(1,8)]
        s=data["summary"]
        for line in [f"Files: {s['files']}",f"Lines of code: {s['lines']}",
                     f"Detected definitions: {s['definitions']}",f"Import statements: {s['imports']}",
                     f"Architecture health heuristic: {s['health']}/100",
                     f"Detected circular dependency cycles: {s['cycles']}"]:
            story.append(Paragraph(line,styles["BodyText"]))
        story.append(Spacer(1,10)); story.append(Paragraph("Language distribution",styles["Heading2"]))
        rows=[["Language","Files"]]+[[k,str(v)] for k,v in s["languages"].items()]
        t=Table(rows); t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#252b42")),
            ("TEXTCOLOR",(0,0),(-1,0),colors.white),("GRID",(0,0),(-1,-1),.4,colors.grey),
            ("PADDING",(0,0),(-1,-1),6)])); story.append(t)
        story.append(Spacer(1,10)); story.append(Paragraph("Analysis notes",styles["Heading2"]))
        for note in data["notes"]: story.append(Paragraph("• "+note,styles["BodyText"]))
        doc.build(story)
        return send_file(out,as_attachment=True)
    except Exception as e:
        flash("PDF generation failed: "+str(e)); return redirect(url_for("project",project_id=project_id))

if __name__ == "__main__":
    app.run(debug=True, port=5000)
