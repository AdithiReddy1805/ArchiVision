# ArchiVision — Multi-language Architecture Analyzer

A local Flask application that accepts ZIP archives of source projects, detects supported languages, extracts structural information with Tree-sitter where available, infers simple file-level dependencies, visualizes the project graph, generates evidence-based Mermaid UML views (class, component/dependency and package), and generates PDF reports. Optional AI explanations use an OpenAI-compatible API.

## Quick start (Windows PowerShell)

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env
# Edit .env and add OPENAI_API_KEY if you want AI explanations.
python app.py
```

Open http://127.0.0.1:5000 and create an account.

## Supported extensions

Python, Java, JavaScript/JSX, TypeScript/TSX, C, C++, C#, PHP, Go, Ruby, Kotlin, Swift, Rust, Scala, HTML, CSS/SCSS, SQL, Shell, Vue, Dart, Lua, R, Objective-C, Perl, Elixir, Erlang, Haskell, OCaml, Clojure, Groovy, YAML, XML, JSON and TOML.

Tree-sitter language availability varies by installed language-pack version. If a grammar is unavailable, ArchiVision falls back to lightweight definition/import pattern detection. This fallback is not a full parser.

## UML diagram support

- Class view lists class/type declarations detected by the available parser; member signatures and inheritance are not yet comprehensively extracted.
- Component/dependency view visualizes inferred file import relationships.
- Package view groups files by their source folders.
- Diagrams render in the UML Studio and can be downloaded as SVG.
- Sequence, activity and use-case diagrams are not yet implemented in this starter.

## Current MVP boundaries

- ZIP upload only; max upload size 50 MB.
- Source files up to 500 KB each; maximum 1,200 analysed files.
- Python/Java/JavaScript/TypeScript/C/C++ and other listed languages use best-effort parsing.
- Cross-file dependency edges are inferred from import/include text and matching file stems. Dynamic imports, reflection, build-system resolution and runtime calls may not be detected.
- The health score is a transparent heuristic based on detected cycles and isolated files, not a formal quality/security rating.
- Uploaded code is analysed as text and is never executed.
- AI explanations require a valid API key and may send selected source text (up to 12,000 characters) to the configured provider. Do not upload confidential code unless you are authorized to share it.
- Authentication is a simple local demo implementation. Before deployment, add CSRF protection, rate limiting, secure cookie settings, stronger authorization controls, upload quotas, malware scanning and production secret management.

## Project structure

```text
archivision/
  app.py
  requirements.txt
  .env.example
  templates/
  static/
  uploads/       # created at runtime
  reports/       # created at runtime
```

## UML Studio (extended)
The analysis page now offers six static-analysis diagram views: Class, Component/Dependency, Package, Sequence, Activity and Use Case. Sequence relationships are inferred from import edges; activity and use-case views are heuristic summaries derived from detected functions/routes. They are not runtime traces or a replacement for requirements validation. Use the UML Studio controls to request an AI explanation of the currently selected diagram (requires the configured OpenAI-compatible API credentials) and export the active diagram as SVG or PNG. Uploaded source code is not executed.
